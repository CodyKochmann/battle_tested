''' dedicated namespace for the new beta :) '''

from battle_tested.beta.api import fuzz
